package game.engine.monsters;

import game.engine.Role;

public class Dasher extends Monster {
	private int momentumTurns;
	private int turns=0;
	public Dasher(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.momentumTurns = 0;
	}
	
	public int getMomentumTurns() {
		return momentumTurns;
	}
	
	public void setMomentumTurns(int momentumTurns) {
		this.momentumTurns = momentumTurns;
	}
	public void executePowerupEffect(Monster opponentMonster) {
	    this.setMomentumTurns(3);
	}
	public void move(int distance) {
	    if (turns > 0) {
	        super.move(distance * 3);
	        turns--;
	    } else {
	        super.move(distance * 2);
	    }
}
}