package game.engine.monsters;

import game.engine.Board;
import game.engine.Constants;
import game.engine.Role;

public class Schemer extends Monster {
	
	public Schemer(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
	}

	private int stealEnergyFrom(Monster target) {
		int targetBefore = target.getEnergy();
		target.alterEnergy(-Math.min(Constants.SCHEMER_STEAL, targetBefore));
		return Math.max(0, targetBefore - target.getEnergy());
	}

	@Override
	public void executePowerupEffect(Monster opponentMonster) {
		int totalStolen = stealEnergyFrom(opponentMonster);
		for (Monster stationedMonster : Board.getStationedMonsters()) {
			totalStolen += stealEnergyFrom(stationedMonster);
		}
		alterEnergy(totalStolen);
	}

	@Override
	public void setEnergy(int energy) {
		int currentEnergy = getEnergy();
		int delta = energy - currentEnergy;
		super.setEnergy(currentEnergy + delta + 10);
	}
}
