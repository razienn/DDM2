package game.engine.cells;

import game.engine.Board;
import game.engine.Role;
import game.engine.interfaces.CanisterModifier;
import game.engine.monsters.Monster;

public class DoorCell extends Cell implements CanisterModifier {
	private Role role;
	private int energy;
	private boolean activated;
	
	public DoorCell(String name, Role role, int energy) {
		super(name);
		this.role = role;
		this.energy = energy;
		this.activated = false;
	}
	
	public Role getRole() {
		return role;
	}
	
	public int getEnergy() {
		return energy;
	}
	
	public boolean isActivated() {
		return activated;
	}

	public void setActivated(boolean isActivated) {
		this.activated = isActivated;
	}

	@Override
	public void onLand(Monster landingMonster, Monster opponentMonster) {
		super.onLand(landingMonster, opponentMonster);
		if (activated) {
			return;
		}

		int signedEnergy = landingMonster.getRole() == role ? energy : -energy;
		boolean changed = applyDoorEffect(landingMonster, signedEnergy);

		for (Monster stationedMonster : Board.getStationedMonsters()) {
			if (stationedMonster.getRole() == landingMonster.getRole()) {
				changed = applyDoorEffect(stationedMonster, signedEnergy) || changed;
			}
		}

		if (changed) {
			activated = true;
		}
	}

	private boolean applyDoorEffect(Monster monster, int delta) {
		int before = monster.getEnergy();
		modifyCanisterEnergy(monster, delta);
		return before != monster.getEnergy();
	}


	public void modifyCanisterEnergy(Monster monster, int canisterValue) {
		monster.alterEnergy(canisterValue);
	}
}
