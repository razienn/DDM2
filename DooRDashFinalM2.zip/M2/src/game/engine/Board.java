package game.engine;

import java.util.ArrayList;
import java.util.Collections;

import game.engine.cards.Card;
import game.engine.cells.CardCell;
import game.engine.cells.Cell;
import game.engine.cells.ContaminationSock;
import game.engine.cells.ConveyorBelt;
import game.engine.cells.DoorCell;
import game.engine.cells.MonsterCell;
import game.engine.exceptions.InvalidMoveException;
import game.engine.monsters.Monster;

public class Board {
	private Cell[][] boardCells;
	private static ArrayList<Monster> stationedMonsters;
	private static ArrayList<Card> originalCards;
	public static ArrayList<Card> cards;
	
	public Board(ArrayList<Card> readCards) {
		this.boardCells = new Cell[Constants.BOARD_ROWS][Constants.BOARD_COLS];
		stationedMonsters = new ArrayList<Monster>();
		originalCards = readCards;
		cards = new ArrayList<Card>();
		setCardsByRarity();
		reloadCards();
	}
	
	public Cell[][] getBoardCells() {
		return boardCells;
	}
	
	public static ArrayList<Monster> getStationedMonsters() {
		return stationedMonsters;
	}
	
	public static void setStationedMonsters(ArrayList<Monster> stationedMonsters) {
		Board.stationedMonsters = stationedMonsters;
	}

	public static ArrayList<Card> getOriginalCards() {
		return originalCards;
	}
	
	public static ArrayList<Card> getCards() {
		return cards;
	}
	
	public static void setCards(ArrayList<Card> cards) {
		Board.cards = cards;
	}

	private int[] indexToRowCol(int index) {
		int rowFromBottom = index / Constants.BOARD_COLS;
		int col = index % Constants.BOARD_COLS;
		if (rowFromBottom % 2 == 1) {
			col = (Constants.BOARD_COLS - 1) - col;
		}
		int row = (Constants.BOARD_ROWS - 1) - rowFromBottom;
		return new int[] { row, col };
	}

	private Cell getCell(int index) {
		int[] rowCol = indexToRowCol(index);
		return boardCells[rowCol[0]][rowCol[1]];
	}

	private void setCell(int index, Cell cell) {
		int[] rowCol = indexToRowCol(index);
		boardCells[rowCol[0]][rowCol[1]] = cell;
	}

	public void initializeBoard(ArrayList<Cell> specialCells) {
		ArrayList<DoorCell> doorCells = new ArrayList<DoorCell>();
		ArrayList<ConveyorBelt> conveyorBelts = new ArrayList<ConveyorBelt>();
		ArrayList<ContaminationSock> contaminationSocks = new ArrayList<ContaminationSock>();

		for (Cell cell : specialCells) {
			if (cell instanceof DoorCell) {
				doorCells.add((DoorCell) cell);
			} else if (cell instanceof ConveyorBelt) {
				conveyorBelts.add((ConveyorBelt) cell);
			} else if (cell instanceof ContaminationSock) {
				contaminationSocks.add((ContaminationSock) cell);
			}
		}

		int doorPointer = 0;
		for (int i = 0; i < Constants.BOARD_SIZE; i++) {
			if (contains(Constants.CARD_CELL_INDICES, i)) {
				setCell(i, new CardCell("Card Cell"));
			} else if (contains(Constants.MONSTER_CELL_INDICES, i)) {
				int monsterIndex = positionOf(Constants.MONSTER_CELL_INDICES, i);
				Monster stationedMonster = stationedMonsters.get(monsterIndex);
				stationedMonster.setPosition(i);
				setCell(i, new MonsterCell(stationedMonster.getName(), stationedMonster));
			} else if (contains(Constants.CONVEYOR_CELL_INDICES, i)) {
				setCell(i, conveyorBelts.get(positionOf(Constants.CONVEYOR_CELL_INDICES, i)));
			} else if (contains(Constants.SOCK_CELL_INDICES, i)) {
				setCell(i, contaminationSocks.get(positionOf(Constants.SOCK_CELL_INDICES, i)));
			} else if (i % 2 == 1) {
				setCell(i, doorCells.get(doorPointer++));
			} else {
				setCell(i, new Cell("Rest Cell"));
			}
		}
	}

	private void setCardsByRarity() {
		ArrayList<Card> expandedCards = new ArrayList<Card>();
		for (Card card : originalCards) {
			for (int i = 0; i < card.getRarity(); i++) {
				expandedCards.add(card);
			}
		}
		originalCards = expandedCards;
	}

	public static void reloadCards() {
		cards = new ArrayList<Card>(originalCards);
		Collections.shuffle(cards);
	}

	public static Card drawCard() {
		if (cards.isEmpty()) {
			reloadCards();
		}
		return cards.remove(0);
	}

	public void moveMonster(Monster currentMonster, int roll, Monster opponentMonster) throws InvalidMoveException {
		int originalPosition = currentMonster.getPosition();
		int opponentOriginalPosition = opponentMonster.getPosition();

		currentMonster.move(roll);
		getCell(currentMonster.getPosition()).onLand(currentMonster, opponentMonster);

		if (currentMonster.getPosition() == opponentMonster.getPosition()) {
			currentMonster.setPosition(originalPosition);
			opponentMonster.setPosition(opponentOriginalPosition);
			updateMonsterPositions(currentMonster, opponentMonster);
			throw new InvalidMoveException();
		}

		if (currentMonster.isConfused() || opponentMonster.isConfused()) {
			currentMonster.decrementConfusion();
			opponentMonster.decrementConfusion();
		}

		updateMonsterPositions(currentMonster, opponentMonster);
	}

	private void updateMonsterPositions(Monster player, Monster opponent) {
		for (int i = 0; i < Constants.BOARD_SIZE; i++) {
			getCell(i).setMonster(null);
		}

		getCell(player.getPosition()).setMonster(player);
		getCell(opponent.getPosition()).setMonster(opponent);
	}

	private boolean contains(int[] arr, int target) {
		for (int value : arr) {
			if (value == target) {
				return true;
			}
		}
		return false;
	}

	private int positionOf(int[] arr, int target) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == target) {
				return i;
			}
		}
		return -1;
	}
}
